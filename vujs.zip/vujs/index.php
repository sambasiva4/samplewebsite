<?php

?>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/vue/dist/vue.js"></script>
<script src="https://unpkg.com/axios/dist/axios.min.js"></script>
<style>
.modal-mask {position: fixed;z-index: 9998;top: 0;left: 0;width: 100%;height: 100%;background-color: rgba(0, 0, 0, .5);display: table;transition: opacity .3s ease;}
.modal-wrapper {display: table-cell;vertical-align: middle;}
.modal-dialog {max-width: 500px;background: #fff;padding: 20px;border-radius: 10px;}
.pagination .page-item.active .page-link {background-color: #337ab7;border-color: #337ab7;color: #ffffff;}
.page-item a {cursor: pointer;}
.page-item.active a {pointer-events: none;}
</style>

<div class="container" id="crudApp">
    <br />
    <h3 align="center">User Data Table</h3>
    <br />
    <div class="panel panel-default">
        <div class="panel-heading">
            <div class="row">
                <div class="col-md-12" align="right">
                    <input type="button" class="btn btn-success btn-xs mb-2" @click="openModel" value="Add" />
                </div>
            </div>
        </div>
        <div class="panel-body">
            <div class="row mb-3 align-items-center">
                <div class="form-group col-xl-4 col-md-6 col-12">
                    <input type="text" class="form-control" name="search_query" v-model="searchQuery" @input="filterData" placeholder="Search by first or last name">
                </div>

                <div class="col-2 ms-auto text-end">
                    <p class="m-0 fs-5">Total Records: {{ totalItems }}</p>
                </div>
            </div>

            <div class="table-responsive">
                <table class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th @click="sortBy('firstname')">Firstname <i class="fas" :class="{ 'fa-sort-up': sortKey === 'firstname' && !reverse, 'fa-sort-down': sortKey === 'firstname' && reverse }"></i></th>
                        <th @click="sortBy('lastname')">Lastname <i class="fas" :class="{ 'fa-sort-up': sortKey === 'lastname' && !reverse, 'fa-sort-down': sortKey === 'lastname' && reverse }"></i></th>
                        <th>Email</th>
                        <th>Edit</th>
                        <th>Delete</th>
                    </tr>
                    </thead>
                    <tbody>
                    <tr v-for="row in paginate()">
                        <td>{{ row.firstname }}</td>
                        <td>{{ row.lastname }}</td>
                        <td>{{ row.email }}</td>

                        <td><button type="button" name="edit" class="btn btn-primary btn-xs edit" @click="fetchData(row.id)">Edit</button></td>
                        <td><button type="button" name="delete" class="btn btn-danger btn-xs delete" @click="deleteData(row.id)">Delete</button></td>
                    </tr>
                    </tbody>
                </table>
            </div>

            <div v-if="totalItems > 2">
                <div class="pagination">
                    <ul class="pagination">
                        <li class="page-item" v-if="currentPage > 1">
                            <a class="page-link" @click="prevPage()">Previous</a>
                        </li>
                        <li class="page-item" v-for="pageNumber in Math.ceil(totalItems / itemsPerPage)" :key="pageNumber" :class="{ active: currentPage === pageNumber }">
                            <a class="page-link" @click="currentPage = pageNumber">{{ pageNumber }}</a>
                        </li>
                        <li class="page-item" v-if="currentPage < Math.ceil(totalItems / itemsPerPage)">
                            <a class="page-link" @click="nextPage()">Next</a>
                        </li>
                    </ul>
                </div>
            </div>

        </div>
    </div>
    <div v-if="myModel">
        <transition name="model">
            <div class="modal-mask">
                <div class="modal-wrapper">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h4 class="modal-title ">{{ dynamicTitle }}</h4>
                                <button type="button" class="close ms-auto" @click="myModel=false"><span aria-hidden="true">&times;</span></button>

                            </div>
                            <div class="modal-body">
                                <div class="form-group">
                                    <label>Enter First Name</label>
                                    <input type="text" class="form-control" v-model="firstname" />
                                </div>
                                <div class="form-group">
                                    <label>Enter Last Name</label>
                                    <input type="text" class="form-control" v-model="lastname" />
                                </div>
                                <div class="form-group">
                                    <label>Email</label>
                                    <input type="text" class="form-control" v-model="email" />
                                </div>
                                <br />
                                <div align="center">
                                    <input type="hidden" v-model="hiddenId" />
                                    <input type="button" class="btn btn-success btn-xs" v-model="actionButton" @click="submitData" />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </transition>
    </div>
</div>

<script>
    var application = new Vue({
        el: '#crudApp',
        data: {
            allData: '',
            filteredItems: '',
            myModel: false,
            actionButton: 'Insert',
            dynamicTitle: 'Add Data',
            searchQuery: '',
            currentPage: 1,
            itemsPerPage: 7,
            totalItems: 0,
            sortKey: '',
            reverse: false
        },
        methods: {
            fetchAllData: function() {
                axios.post('action.php', {
                    action: 'fetchall'
                }).then(function(response) {
                    application.allData = response.data;
                    application.filteredItems = response.data;
                    application.totalItems = response.data.length;
                });
            },

            filterData: function() {
                this.filteredItems = this.allData.filter(item => {
                    return item.firstname.toLowerCase().includes(this.searchQuery.toLowerCase()) ||
                        item.lastname.toLowerCase().includes(this.searchQuery.toLowerCase()) ||
                        item.email.toLowerCase().includes(this.searchQuery.toLowerCase());
                });
                this.totalItems = this.filteredItems.length;
            },

            paginate: function() {
                const start = (this.currentPage - 1) * this.itemsPerPage;
                const end = start + this.itemsPerPage;
                return this.filteredItems.slice(start, end);
            },

            nextPage: function() {
                if (this.currentPage < Math.ceil(this.totalItems / this.itemsPerPage)) {
                    this.currentPage++;
                    this.filterData();
                }
            },

            prevPage: function() {
                if (this.currentPage > 1) {
                    this.currentPage--;
                    this.filterData();
                }
            },

            sortBy: function(key) {
                this.reverse = (this.sortKey === key) ? !this.reverse : false;
                this.sortKey = key;
                this.filteredItems = this.filteredItems.sort((a, b) => {
                    let comparison = 0;
                    if (a[key] > b[key]) {
                        comparison = 1;
                    } else if (a[key] < b[key]) {
                        comparison = -1;
                    }
                    return this.reverse ? comparison * -1 : comparison;
                });
            },

            openModel: function() {
                application.firstname = '';
                application.lastname = '';
                application.email = '';
                application.actionButton = "Insert";
                application.dynamicTitle = "Add Data";
                application.myModel = true;
            },
            submitData: function() {

                if (application.firstname != '' && application.lastname != '') {
                    if (application.actionButton == 'Insert') {
                        axios.post('action.php', {
                            action: 'insert',
                            firstName: application.firstname,
                            lastName: application.lastname,
                            email: application.email,

                        }).then(function(response) {
                            application.myModel = false;
                            application.fetchAllData();
                            application.firstname = '';
                            application.lastname = '';
                            application.email = '';
                            alert(response.data.message);
                        });
                    }
                    if (application.actionButton == 'Update') {
                        axios.post('action.php', {
                            action: 'update',
                            firstName: application.firstname,
                            lastName: application.lastname,
                            email: application.email,
                            hiddenId: application.hiddenId
                        }).then(function(response) {
                            application.myModel = false;
                            application.fetchAllData();
                            application.firstname = '';
                            application.lastname = '';
                            application.email = '';
                            application.hiddenId = '';
                            console.log(response.data.message);
                        });
                    }
                } else {
                    alert("Fill All Field");
                }
                application.searchQuery = '';

            },
            fetchData: function(id) {
                axios.post('action.php', {
                    action: 'fetchSingle',
                    id: id
                }).then(function(response) {
                    application.firstname = response.data.firstname;
                    application.lastname = response.data.lastname;
                    application.email = response.data.email;
                    application.hiddenId = response.data.id;
                    application.myModel = true;
                    application.actionButton = 'Update';
                    application.dynamicTitle = 'Edit Data';
                });
            },
            deleteData: function(id) {
                if (confirm("Are you sure you want to remove this data?")) {
                    axios.post('action.php', {
                        action: 'delete',
                        id: id
                    }).then(function(response) {
                        application.fetchAllData();
                        alert(response.data.message);
                    });
                }
                application.searchQuery = '';

            }
        },
        created: function() {
            this.fetchAllData();
        }
    });
</script>