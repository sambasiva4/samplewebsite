<?php

// Database configuration
$servername = "localhost";
$username = "mysqluser";
$password = "mysqlpass"; // Your MySQL password
$dbname = "iowa_tobacco"; // Replace with your actual database name

try {
    $pdo = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $page= 1;
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $page = $_POST['page'];
    } 
    $limit = 15;
    $offset = ($page - 1) * $limit;


    $stmt = $pdo->prepare("SELECT * FROM mdl_user LIMIT :limit OFFSET :offset");
    $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
    $stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
    $stmt->execute();
    
    $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $countStmt = $pdo->query("SELECT COUNT(*) FROM mdl_user");
    $totalRows = $countStmt->fetchColumn();

    $data = [
        'data' => $result,
        'total' => $totalRows,
        'page' => $page,
        'pages' => ceil($totalRows / $limit)
    ];

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        header('Content-Type: application/json');
        echo json_encode($data);
        exit;
    }

} catch (PDOException $e) {
    $data = ['error' => $e->getMessage()];
}

?>
 <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
 <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<div id="app">
  <input type="text" v-model="filter" placeholder="Filter by name or email">

  <table class="table table-success table-striped">
    <thead>
      <tr>
        <th>ID</th>
        <th>Firstname <button @click="sort('firstname')">Sort</button></th>
        <th>Email <button @click="sort('email')">Sort</button></th>
      </tr>
    </thead>
    <tbody>
      <tr v-for="row in filteredItems" :key="row.id">
        <td>{{ row.id }}</td>
        <td>{{ row.firstname }}</td>
        <td>{{ row.email }}</td>
      </tr>
    </tbody>
  </table>
  
  <div v-if="totalPages > 1">
    <button v-on:click="changePage(1)">First</button>
    <button v-if="currentPage > 2" v-on:click="changePage(currentPage - 1)">Prev</button>
    <button v-for="page in pages" v-on:click="changePage(page)">{{ page }}</button>
    <button v-if="currentPage < totalPages - 1" v-on:click="changePage(currentPage + 1)">Next</button>
    <button v-on:click="changePage(totalPages)">Last</button>
  </div>
  
</div>

<!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/vue/3.4.38/vue.cjs.js"></script> -->

<script src="https://cdn.jsdelivr.net/npm/vue@2.7.16/dist/vue.js"></script>


<script>
  new Vue({
    el: '#app',
    data() {
      return {
        items: <?= json_encode($data['data']) ?>,
        currentPage: <?= $data['page'] ?>,
        totalPages: <?= $data['pages'] ?>,
        pages: [],
        filter: '',
        sortBy: '',
        sortOrder: 1
      };
    },
    mounted() {
      this.generatePages();
    },
    computed: {
      filteredItems() {
        let filteredItems = this.items;
        if (this.filter) {
          filteredItems = filteredItems.filter(item => {
            return item.firstname.toLowerCase().includes(this.filter.toLowerCase()) || item.email.toLowerCase().includes(this.filter.toLowerCase());
          });
        }
        if (this.sortBy) {
          filteredItems = filteredItems.sort((a, b) => {
            if (a[this.sortBy] < b[this.sortBy]) {
              return this.sortOrder;
            } else if (a[this.sortBy] > b[this.sortBy]) {
              return -this.sortOrder;
            } else {
              return 0;
            }
          });
        }
        return filteredItems;
      }
    },
    methods: {
      generatePages() {
        const pages = [];
        for (let i = 1; i <= this.totalPages; i++) {
          if (i === 1 || i === this.totalPages || (i >= this.currentPage - 2 && i <= this.currentPage + 2)) {
            pages.push(i);
          } else if (i === this.currentPage - 3 || i === this.currentPage + 3) {
            pages.push('...');
          }
        }
        this.pages = pages;
      },
      changePage(page) {
        const formData = new FormData();
        formData.append('page', page);
        fetch('', {
          method: 'POST',
          body: formData
        })
        
        .then(response => response.json())
        .then(data => {
          this.items = data.data;
          this.currentPage = data.page;
          this.totalPages = data.pages;
          this.generatePages();
        })
        .catch(error => console.error(error));
      },
      sort(column) {
        this.sortBy = column;
        this.sortOrder = this.sortOrder === 1 ? -1 : 1;
      }
    }
  });
</script>